package aula2603;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula2603ApplicationTests {

	@Test
	void contextLoads() {
	}

}
