package aula2603;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula2603Application {
	public static void main(String[] args) {
		SpringApplication.run(Aula2603Application.class, args);
	}
}