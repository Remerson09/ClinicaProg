package aula2603.controller;

import aula2603.model.entity.Consulta;
import aula2603.model.entity.Medico;
import aula2603.model.entity.Paciente;
import aula2603.repository.ConsultaRepository;
import aula2603.repository.MedicoRepository;
import aula2603.repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.time.LocalDateTime;

import java.util.List;

@Controller
@RequestMapping("/consultas")
public class ConsultaController {

    @Autowired
    private ConsultaRepository consultaRepository;

    @Autowired
    private PacienteRepository pacienteRepository;

    @Autowired
    private MedicoRepository medicoRepository;

    @GetMapping
    public String listar(Model model) {
        // Garanta que está retornando a lista de consultas diretamente
        model.addAttribute("consultas", consultaRepository.findAllWithPacienteAndMedico());
        return "consulta/list"; // Verifique se este é o caminho correto do template
    }

    @GetMapping("/nova")
    public String novoForm(Model model) {
        prepararForm(model, new Consulta());
        return "consulta/form";
    }

    // Formulário pré-preenchido para paciente específico
    @GetMapping("/nova/{id}")
    public String novoFormComPaciente(@PathVariable Long id, Model model) {
        Consulta consulta = new Consulta();
        consulta.setPaciente(pacienteRepository.findById(id).orElseThrow());
        prepararForm(model, consulta);
        return "consulta/form";
    }

    // Método auxiliar para evitar duplicação
    private void prepararForm(Model model, Consulta consulta) {
        model.addAttribute("consulta", consulta);
        model.addAttribute("pacientes", pacienteRepository.findAll());
        model.addAttribute("medicos", medicoRepository.findAllByOrderByNomeAsc());
    }

    @PostMapping("/salvar")
    public String salvar(@ModelAttribute Consulta consulta,
                         RedirectAttributes redirectAttributes) {

        try {
            // Verifica se o paciente foi associado
            if (consulta.getPaciente() == null || consulta.getPaciente().getId() == null) {
                throw new IllegalArgumentException("Paciente não informado");
            }

            // Verifica se o médico foi selecionado
            if (consulta.getMedico() == null || consulta.getMedico().getId() == null) {
                throw new IllegalArgumentException("Médico não selecionado");
            }

            // Salva a consulta
            consultaRepository.save(consulta);

            redirectAttributes.addFlashAttribute("success", "Consulta agendada com sucesso");
            return "redirect:/pacientes/consultas/" + consulta.getPaciente().getId();

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Erro ao agendar consulta: " + e.getMessage());
            return "redirect:/consultas/nova/" + (consulta.getPaciente() != null ? consulta.getPaciente().getId() : "");
        }
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model) {
        Consulta consulta = consultaRepository.findByIdWithPacienteAndMedico(id)
                .orElseThrow(() -> new IllegalArgumentException("Consulta não encontrada"));

        model.addAttribute("consulta", consulta);
        model.addAttribute("medicos", medicoRepository.findAll());
        model.addAttribute("pacientes", pacienteRepository.findAll());

        return "consulta/editar";
    }

    @PostMapping("/atualizar/{id}")
    public String atualizar(@PathVariable Long id, @ModelAttribute Consulta consulta,
                            BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("medicos", medicoRepository.findAll());
            model.addAttribute("pacientes", pacienteRepository.findAll());
            return "consulta/editar";
        }

        consulta.setId(id);
        consultaRepository.save(consulta);
        return "redirect:/pacientes/consultas/" + consulta.getPaciente().getId();
    }


    @GetMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Consulta consulta = consultaRepository.findByIdWithPacienteAndMedico(id)
                    .orElseThrow(() -> new IllegalArgumentException("Consulta não encontrada"));

            Long pacienteId = consulta.getPaciente().getId();
            consultaRepository.delete(consulta);

            redirectAttributes.addFlashAttribute("success", "Consulta excluída com sucesso");
            return "redirect:/pacientes/consultas/" + pacienteId;

        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Erro ao excluir consulta: " + e.getMessage());
            return "redirect:/consultas";
        }
    }
    @GetMapping("/buscar-por-data")
    public String buscarPorData(@RequestParam("data")
                                @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
                                LocalDate data, Model model) {
        List<Consulta> consultas = consultaRepository.findByDataConsulta(data);
        model.addAttribute("consultas", consultas);
        return "consulta/list"; // Certifique-se que este é o seu template de listagem
    }

}