/*package aula2603.model.entity;

public enum AgendaStatus {
    DISPONIVEL, // Horário está livre para agendamento
    AGENDADO,   // Horário foi agendado por um paciente
    CANCELADO   // Agendamento foi cancelado (pelo paciente ou clínica)
}

 */
